/**
 * 2303-2 百鸡问题
 * 标准程序
 */
#include <iostream>
using namespace std;

int main() {
    int X, Y, Z, n, m;
    cin >> X >> Y >> Z >> n >> m;

    int count = 0;

    // 枚举公鸡数量
    for (int a = 0; a <= m; a++) {
        // 枚举母鸡数量
        for (int b = 0; b <= m - a; b++) {
            // 计算小鸡数量
            int c = m - a - b;

            // 检查小鸡数量是否能被Z整除（Z只小鸡1元）
            if (c % Z == 0) {
                // 计算总花费
                int cost = a * X + b * Y + c / Z;

                // 检查是否等于n元
                if (cost == n) {
                    count++;
                }
            }
        }
    }

    cout << count << endl;

    return 0;
}
